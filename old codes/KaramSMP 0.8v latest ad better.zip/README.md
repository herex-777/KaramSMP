# KaramSMP

Paper 1.21.11 plugin for KaramSMP.

## Features

- `/gmsp` / `/gsmp` spectator toggle
- `/nightvision` / `/nv` night vision toggle
- Configurable TAB header/footer with hex colors and styled Unicode text support
- Rank prefixes/suffixes, rank permissions, and database-backed assigned ranks
- SQLite/MySQL/YAML rank storage
- Configurable chat format
- Join/quit messages
- `/discord`, `/guide`, and `/store` info commands
- Region protection system with wand selections and flags
- Animated multi-file scoreboards in `plugins/KaramSMP/scoreboards/`
- DonutSMP-style homes system with GUI, beds, delete buttons, teleport countdown, and movement cancel

## Build

```bash
mvn clean package
```

The built jar will be:

```text
target/KaramSMP-0.8.jar
```

## Home commands

```text
/home
/home <name>
/sethome <name>
/delhome <name>
```

`/home` opens the GUI. Light blue beds teleport to saved homes, white beds create a new home, and light blue dye deletes a saved home.

## Region commands

```text
/region wand
/region pos1
/region pos2
/region create <name>
/region delete <name>
/region list
/region info <name>
/region here
/region flag <name> <flag> <true|false|reset>
/region owner add|remove <region> <player>
/region member add|remove <region> <player>
/region priority <region> <priority>
/region redefine <region>
/region expand <region> <direction> <amount>
/region contract <region> <direction> <amount>
/region message <region> greeting|farewell <message|clear>
/region tp <region>
/region save
/region reload
```
