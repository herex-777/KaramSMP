# KaramSMP

Paper 1.21.x SMP plugin by Herex._.7.

## Build

```bash
mvn clean package
```

The built jar will be:

```text
target/KaramSMP-1.0.jar
```

## Main player commands

- `/gmsp` or `/gsmp` - toggle spectator/survival, requires `karamsmp.helper.gmsp`.
- `/nightvision` or `/nv` - toggle night vision.
- `/home`, `/home <name>`, `/sethome <name>`, `/delhome <name>` - homes GUI and teleport system.
- `/spawn` - teleport to server spawn.
- `/rtp` - opens random teleport GUI for overworld/nether/end.
- `/blance`, `/balance`, `/bal`, `/money` - check your balance.
- `/pay <player> <amount>` - pay another player.
- `/discord`, `/guide`, `/store` - configurable info commands.

## Staff/admin commands

- `/setspawn` - set first-join spawn, permission `karamsmp.spawn.set`.
- `/blance <player>` - check another player's balance, permission `karamsmp.balance.others`.
- `/rtp <overworld|nether|end>` - direct RTP section teleport, permission `karamsmp.rtp.admin`.
- `/rank help` - manage ranks.
- `/region help` - manage protection regions.
- `/kscoreboard help` - manage scoreboards.
- `/reload` - reload KaramSMP, permission `karamsmp.reload`.

## Economy placeholders

Use these in scoreboards, TAB, chat, and messages:

- `%balance%`
- `%money%`
- `%balance_plain%`
- `%money_plain%`
- `%karamsmp_balance%`
- `%karamsmp_balance_formatted%`
- `%karamsmp_balance_plain%`
- `%karamsmp_money%`

Balances are formatted like `$125K`, `$125.1K`, `$1M`, `$2.61B`.

## Economy storage

By default the economy uses `economy.storage.type: same-as-database`, so it follows `database.type` from `config.yml`.

Supported storage:

- SQLite
- MySQL
- YAML

## Random teleport

Edit the `rtp:` section in `config.yml` to change:

- GUI title/rows
- world slots/items/lore
- world names (`world`, `world_nether`, `world_the_end` by default)
- min/max radius
- teleport delay
- cancel/teleport sounds
- messages

RTP has a 5-second delay by default and cancels if the player moves.
