package me.herex.karmsmp.commands;

import me.herex.karmsmp.KaramSMP;
import me.herex.karmsmp.economy.EconomyManager;
import me.herex.karmsmp.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class BalanceCommand implements CommandExecutor, TabCompleter {

    private final KaramSMP plugin;
    private final EconomyManager economyManager;

    public BalanceCommand(KaramSMP plugin, EconomyManager economyManager) {
        this.plugin = plugin;
        this.economyManager = economyManager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!plugin.getConfig().getBoolean("economy.enabled", true)) {
            sender.sendMessage(color("economy.messages.disabled", "&cThe balance system is disabled."));
            return true;
        }

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color("economy.messages.only-players", "&cOnly players can use this command."));
                return true;
            }
            double balance = economyManager.getBalance(player);
            sender.sendMessage(format(player, "economy.messages.balance", "&8• &aʙᴀʟᴀɴᴄᴇ &8» &fYour balance is &a%balance%&f.", player.getName(), balance));
            return true;
        }

        if (!sender.hasPermission("karamsmp.balance.others") && !sender.hasPermission("karamsmp.admin")) {
            sender.sendMessage(color("economy.messages.no-permission", "&cYou don't have permission to use this command!"));
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        double balance = economyManager.getBalance(target.getUniqueId(), target.getName() == null ? args[0] : target.getName());
        sender.sendMessage(format(sender instanceof Player player ? player : null, "economy.messages.balance-other", "&8• &aʙᴀʟᴀɴᴄᴇ &8» &e%player% &fhas &a%balance%&f.", target.getName() == null ? args[0] : target.getName(), balance));
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1 && (sender.hasPermission("karamsmp.balance.others") || sender.hasPermission("karamsmp.admin"))) {
            List<String> names = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                names.add(player.getName());
            }
            return names;
        }
        return Collections.emptyList();
    }

    private String format(Player player, String path, String fallback, String targetName, double balance) {
        String message = plugin.getConfig().getString(path, fallback)
                .replace("%player%", targetName == null ? "Unknown" : targetName)
                .replace("%balance%", economyManager.format(balance))
                .replace("%balance_plain%", economyManager.formatPlain(balance));
        return player == null ? MessageUtil.color(message) : plugin.getRankManager().applyPlaceholders(player, message);
    }

    private String color(String path, String fallback) {
        return MessageUtil.color(plugin.getConfig().getString(path, fallback));
    }
}
