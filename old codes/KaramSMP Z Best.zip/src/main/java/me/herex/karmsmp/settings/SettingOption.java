package me.herex.karmsmp.settings;

import java.util.List;

public final class SettingOption {

    private final String id;
    private final int slot;
    private final String material;
    private final String name;
    private final List<String> lore;
    private final String command;
    private final String sound;
    private final boolean defaultEnabled;
    private final String permission;

    public SettingOption(String id, int slot, String material, String name, List<String> lore, boolean defaultEnabled) {
        this(id, slot, material, name, lore, "", "ENTITY_EXPERIENCE_ORB_PICKUP", defaultEnabled, "");
    }

    public SettingOption(String id, int slot, String material, String name, List<String> lore, String command, String sound, boolean defaultEnabled, String permission) {
        this.id = id;
        this.slot = slot;
        this.material = material;
        this.name = name;
        this.lore = lore == null ? List.of() : List.copyOf(lore);
        this.command = command == null ? "" : command;
        this.sound = sound == null || sound.isBlank() ? "ENTITY_EXPERIENCE_ORB_PICKUP" : sound;
        this.defaultEnabled = defaultEnabled;
        this.permission = permission == null ? "" : permission;
    }

    public String getId() {
        return id;
    }

    public int getSlot() {
        return slot;
    }

    public String getMaterial() {
        return material;
    }

    public String getName() {
        return name;
    }

    public List<String> getLore() {
        return lore;
    }

    public String getCommand() {
        return command;
    }

    public String getSound() {
        return sound;
    }

    public boolean isDefaultEnabled() {
        return defaultEnabled;
    }

    public String getPermission() {
        return permission;
    }
}
