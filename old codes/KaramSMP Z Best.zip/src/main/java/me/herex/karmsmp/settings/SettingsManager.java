package me.herex.karmsmp.settings;

import me.herex.karmsmp.KaramSMP;
import me.herex.karmsmp.utils.MessageUtil;
import me.herex.karmsmp.utils.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SettingsManager {

    private final KaramSMP plugin;
    private final File file;
    private YamlConfiguration data;
    private final Map<String, SettingOption> options = new LinkedHashMap<>();
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    public SettingsManager(KaramSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), plugin.getConfig().getString("settings.data-file", "settings.yml"));
        load();
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        data = YamlConfiguration.loadConfiguration(file);
        loadOptions();
        writeNewDefaultsToLoadedPlayers();
        save();
    }

    public void reload() {
        data = YamlConfiguration.loadConfiguration(file);
        cooldowns.clear();
        loadOptions();
        writeNewDefaultsToLoadedPlayers();
    }

    public void save() {
        if (data == null) {
            return;
        }
        try {
            data.save(file);
        } catch (IOException exception) {
            plugin.getLogger().warning("Could not save settings.yml: " + exception.getMessage());
        }
    }

    public boolean isEnabled(Player player, String settingId) {
        return isEnabled(player.getUniqueId(), settingId);
    }

    public boolean isEnabled(UUID uuid, String settingId) {
        String id = normalize(settingId);
        SettingOption option = options.get(id);
        boolean fallback = option == null || option.isDefaultEnabled();
        return data.getBoolean("players." + uuid + "." + id, fallback);
    }

    public void setEnabled(Player player, String settingId, boolean enabled) {
        String id = normalize(settingId);
        data.set("players." + player.getUniqueId() + "." + id, enabled);
        save();
    }

    public boolean toggle(Player player, String settingId) {
        boolean newValue = !isEnabled(player, settingId);
        setEnabled(player, settingId, newValue);
        return newValue;
    }

    public boolean toggleBySlot(Player player, int slot) {
        SettingOption option = getOptionBySlot(slot);
        if (option == null) {
            return false;
        }

        if (isOnCooldown(player)) {
            sendCooldownMessage(player);
            return true;
        }

        if (!option.getPermission().isBlank() && !player.hasPermission(option.getPermission())) {
            player.sendMessage(MessageUtil.color(plugin.getConfig().getString("settings.messages.no-permission", "&cYou don't have permission to change this setting!")));
            return true;
        }

        boolean enabled = toggle(player, option.getId());
        markCooldown(player);
        SoundUtil.play(player, option.getSound(), 1.0f, 1.0f);
        refreshOpenItem(player, option);
        executeSettingCommand(player, option, enabled);
        return true;
    }

    public void open(Player player) {
        if (!plugin.getConfig().getBoolean("settings.enabled", true)) {
            player.sendMessage(MessageUtil.color(plugin.getConfig().getString("settings.messages.disabled", "&cSettings are disabled.")));
            return;
        }

        int slots = getGuiSlots();
        String title = MessageUtil.color(plugin.getConfig().getString("settings-gui.title", plugin.getConfig().getString("settings.gui.title", "&0ѕᴇᴛᴛɪɴɢѕ")));
        Inventory inventory = Bukkit.createInventory(new SettingsGuiHolder(player.getUniqueId()), slots, title);

        if (plugin.getConfig().getBoolean("settings-gui.filler.enabled", true)) {
            ItemStack filler = createFillerItem();
            for (int i = 0; i < slots; i++) {
                inventory.setItem(i, filler);
            }
        }

        for (SettingOption option : options.values()) {
            if (option.getSlot() < 0 || option.getSlot() >= inventory.getSize()) {
                continue;
            }
            inventory.setItem(option.getSlot(), createItem(player, option));
        }

        player.openInventory(inventory);
    }

    public Collection<SettingOption> getOptions() {
        return options.values();
    }

    public SettingOption getOption(String id) {
        return options.get(normalize(id));
    }

    public SettingOption getOptionBySlot(int slot) {
        for (SettingOption option : options.values()) {
            if (option.getSlot() == slot) {
                return option;
            }
        }
        return null;
    }

    public String getStatusText(Player player, String settingId) {
        return isEnabled(player, settingId)
                ? plugin.getConfig().getString("settings-gui.status.on", plugin.getConfig().getString("settings.status.on-text", "&a&lON"))
                : plugin.getConfig().getString("settings-gui.status.off", plugin.getConfig().getString("settings.status.off-text", "&c&lOFF"));
    }

    public String getStatusColor(Player player, String settingId) {
        return isEnabled(player, settingId)
                ? plugin.getConfig().getString("settings.status.on-color", "<##7AFC00>")
                : plugin.getConfig().getString("settings.status.off-color", "<##FC0000>");
    }

    public static String normalize(String id) {
        if (id == null) {
            return "";
        }
        return id.toLowerCase(Locale.ROOT).replace('_', '-').replace(' ', '-');
    }

    public static String placeholderKey(String id) {
        return normalize(id).replace('-', '_');
    }

    private void loadOptions() {
        options.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("settings-gui.items");
        if (section == null) {
            section = plugin.getConfig().getConfigurationSection("settings.options");
        }
        if (section == null) {
            loadDefaultOptions();
            return;
        }

        for (String key : section.getKeys(false)) {
            ConfigurationSection itemSection = section.getConfigurationSection(key);
            if (itemSection == null) {
                continue;
            }
            String id = normalize(key);
            int slot = itemSection.getInt("slot", -1);
            String material = itemSection.getString("material", "PAPER");
            String name = itemSection.getString("display-name", itemSection.getString("name", "&a" + id));
            List<String> lore = readLore(itemSection);
            if (lore.isEmpty()) {
                lore = List.of("&fCurrently: %status%");
            }
            String command = itemSection.getString("command", "");
            String sound = itemSection.getString("sound", "ENTITY_EXPERIENCE_ORB_PICKUP");
            boolean defaultEnabled = itemSection.getBoolean("default", true);
            String permission = itemSection.getString("permission", "");
            options.put(id, new SettingOption(id, slot, material, name, lore, command, sound, defaultEnabled, permission));
        }

        if (options.isEmpty()) {
            loadDefaultOptions();
        }
    }

    private List<String> readLore(ConfigurationSection itemSection) {
        if (itemSection.isList("lore")) {
            return itemSection.getStringList("lore");
        }
        String lore = itemSection.getString("lore", "");
        if (lore == null || lore.isEmpty()) {
            return new ArrayList<>();
        }
        return new ArrayList<>(List.of(lore.split("\\n")));
    }

    private ItemStack createFillerItem() {
        Material material = Material.matchMaterial(plugin.getConfig().getString("settings-gui.filler.material", "BLACK_STAINED_GLASS_PANE"));
        if (material == null) {
            material = Material.BLACK_STAINED_GLASS_PANE;
        }
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(MessageUtil.color(plugin.getConfig().getString("settings-gui.filler.display-name", " ")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createItem(Player player, SettingOption option) {
        Material material = Material.matchMaterial(option.getMaterial());
        if (material == null) {
            material = Material.PAPER;
        }
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            boolean enabled = isEnabled(player, option.getId());
            meta.setDisplayName(applySettingPlaceholders(player, option, option.getName()));
            List<String> lore = new ArrayList<>();
            for (String line : option.getLore()) {
                lore.add(applySettingPlaceholders(player, option, line));
            }
            meta.setLore(lore);
            if (plugin.getConfig().getBoolean("settings-gui.enchant-glow", true) && enabled) {
                Enchantment enchantment = Enchantment.getByKey(NamespacedKey.minecraft("unbreaking"));
                if (enchantment != null) {
                    meta.addEnchant(enchantment, 1, true);
                    meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                }
            }
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            item.setItemMeta(meta);
        }
        return item;
    }

    private String applySettingPlaceholders(Player player, SettingOption option, String text) {
        String value = text == null ? "" : text;
        String status = getStatusText(player, option.getId());
        String legacyStatus = getStatusColor(player, option.getId()) + "&l" + (isEnabled(player, option.getId()) ? "ON" : "OFF");
        value = value.replace("%setting%", option.getId())
                .replace("%status%", status)
                .replace("%status_color%", getStatusColor(player, option.getId()))
                .replace("%enabled%", String.valueOf(isEnabled(player, option.getId())))
                .replace("%legacy_status%", legacyStatus);
        return plugin.getRankManager().applyPlaceholders(player, value);
    }

    private void refreshOpenItem(Player player, SettingOption option) {
        Inventory topInventory = player.getOpenInventory().getTopInventory();
        if (topInventory == null || !(topInventory.getHolder() instanceof SettingsGuiHolder)) {
            return;
        }
        if (option.getSlot() >= 0 && option.getSlot() < topInventory.getSize()) {
            topInventory.setItem(option.getSlot(), createItem(player, option));
        }
    }

    private void executeSettingCommand(Player player, SettingOption option, boolean enabled) {
        if (!plugin.getConfig().getBoolean("settings-gui.execute-commands", false)) {
            return;
        }
        String command = option.getCommand();
        if (command == null || command.isBlank()) {
            return;
        }
        String parsed = command.replace("%player%", player.getName())
                .replace("%setting%", option.getId())
                .replace("%enabled%", String.valueOf(enabled));
        while (parsed.startsWith("/")) {
            parsed = parsed.substring(1);
        }
        String commandName = parsed.split(" ", 2)[0].toLowerCase(Locale.ROOT);
        boolean executeOnlyRegistered = plugin.getConfig().getBoolean("settings-gui.execute-only-registered-commands", true);
        if (executeOnlyRegistered && Bukkit.getPluginCommand(commandName) == null) {
            return;
        }
        player.performCommand(parsed);
    }

    private boolean isOnCooldown(Player player) {
        if (!plugin.getConfig().getBoolean("settings-gui.cooldown.enabled", true)) {
            return false;
        }
        long durationMillis = plugin.getConfig().getLong("settings-gui.cooldown.duration", 3L) * 1000L;
        Long lastClick = cooldowns.get(player.getUniqueId());
        return lastClick != null && System.currentTimeMillis() - lastClick < durationMillis;
    }

    private void markCooldown(Player player) {
        if (plugin.getConfig().getBoolean("settings-gui.cooldown.enabled", true)) {
            cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        }
    }

    private void sendCooldownMessage(Player player) {
        long durationMillis = plugin.getConfig().getLong("settings-gui.cooldown.duration", 3L) * 1000L;
        Long lastClick = cooldowns.get(player.getUniqueId());
        if (lastClick == null) {
            return;
        }
        long remaining = Math.max(0L, durationMillis - (System.currentTimeMillis() - lastClick));
        BigDecimal seconds = new BigDecimal(remaining / 1000.0D).setScale(1, RoundingMode.HALF_UP);
        String message = plugin.getConfig().getString("settings-gui.cooldown.message", "&#FF9600Please wait %time% seconds before changing settings again!")
                .replace("%time%", seconds.toString());
        player.sendMessage(MessageUtil.color(message));
    }

    private int getGuiSlots() {
        int configuredSlots = plugin.getConfig().getInt("settings-gui.gui-slots", 0);
        if (configuredSlots > 0) {
            return Math.max(9, Math.min(54, ((configuredSlots + 8) / 9) * 9));
        }
        int rows = plugin.getConfig().getInt("settings.gui.rows", 6);
        return Math.max(1, Math.min(6, rows)) * 9;
    }

    private void writeNewDefaultsToLoadedPlayers() {
        if (data == null || !data.isConfigurationSection("players")) {
            return;
        }
        for (String uuid : data.getConfigurationSection("players").getKeys(false)) {
            for (SettingOption option : options.values()) {
                String path = "players." + uuid + "." + option.getId();
                if (!data.isSet(path)) {
                    data.set(path, option.isDefaultEnabled());
                }
            }
        }
    }

    private void loadDefaultOptions() {
        addDefault("public-chat", 10, "OAK_SIGN", "&#08FB7Bᴘᴜʙʟɪᴄ ᴄʜᴀᴛ", true);
        addDefault("private-messages", 11, "PAPER", "&#08FB7Bᴘʀɪᴠᴀᴛᴇ ᴍᴇssᴀɢᴇs", true);
        addDefault("chat-server-messages", 12, "WRITABLE_BOOK", "&#08FB7Bᴄʜᴀᴛ sᴇʀᴠᴇʀ ᴍᴇssᴀɢᴇs", true);
        addDefault("hotbar-server-messages", 13, "COMPASS", "&#08FB7Bʜᴏᴛʙᴀʀ sᴇʀᴠᴇʀ ᴍᴇssᴀɢᴇs", true);
        addDefault("pay-alerts", 14, "GOLD_INGOT", "&#08FB7Bᴘᴀʏ ᴀʟᴇʀᴛs", true);
        addDefault("bounty-alerts", 15, "DIAMOND_SWORD", "&#08FB7Bʙᴏᴜɴᴛʏ ᴀʟᴇʀᴛs", true);
        addDefault("auction-alerts", 16, "CHEST", "&#08FB7Bᴀᴜᴄᴛɪᴏɴ ᴀʟᴇʀᴛs", true);
        addDefault("fast-crystals", 19, "END_CRYSTAL", "&#08FB7Bғᴀsᴛ ᴄʀʏsᴛᴀʟs", false);
        addDefault("totem-particles", 20, "TOTEM_OF_UNDYING", "&#08FB7Bᴛᴏᴛᴇᴍ ᴘᴀʀᴛɪᴄʟᴇs", true);
        addDefault("explosion-particles", 21, "TNT", "&#08FB7Bᴇxᴘʟᴏsɪᴏɴ ᴘᴀʀᴛɪᴄʟᴇs", true);
        addDefault("explosion-sounds", 22, "BELL", "&#08FB7Bᴇxᴘʟᴏsɪᴏɴ sᴏᴜɴᴅs", true);
        addDefault("quick-auction-buy", 23, "GOLD_BLOCK", "&#08FB7Bǫᴜɪᴄᴋ ᴀᴜᴄᴛɪᴏɴ ʙᴜʏ", false);
        addDefault("chainmail-on-respawn", 24, "CHAINMAIL_CHESTPLATE", "&#08FB7Bᴄʜᴀɪɴᴍᴀɪʟ ᴏɴ ʀᴇsᴘᴀᴡɴ", true);
        addDefault("player-visibility", 28, "ENDER_EYE", "&#08FB7Bᴘʟᴀʏᴇʀ ᴠɪsɪʙɪʟɪᴛʏ", true);
        addDefault("scoreboard", 29, "NAME_TAG", "&#08FB7Bsᴄᴏʀᴇʙᴏᴀʀᴅ", true);
        addDefault("tpa-confirm-menu", 30, "ENDER_PEARL", "&#08FB7Bᴛᴘᴀ ᴄᴏɴғɪʀᴍ ᴍᴇɴᴜ", true);
        addDefault("after-duel-songs", 31, "JUKEBOX", "&#08FB7Bᴀғᴛᴇʀ ᴅᴜᴇʟ sᴏɴɢs", true);
        addDefault("disable-mob-spawns", 32, "ZOMBIE_HEAD", "&#08FB7Bᴅɪsᴀʙʟᴇ ᴍᴏʙ sᴘᴀᴡɴs", false);
        addDefault("sounds-notifications", 33, "NOTE_BLOCK", "&#08FB7Bsᴏᴜɴᴅs ɴᴏᴛɪғɪᴄᴀᴛɪᴏɴs", true);
        addDefault("order-notifications", 34, "HOPPER", "&#08FB7Bᴏʀᴅᴇʀ ɴᴏᴛɪғɪᴄᴀᴛɪᴏɴs", true);
        addDefault("duels-requests", 37, "DIAMOND_SWORD", "&#08FB7Bᴅᴜᴇʟs ʀᴇǫᴜᴇsᴛs", true);
        addDefault("tpa-requests", 38, "ENDER_PEARL", "&#08FB7Bᴛᴘᴀ ʀᴇǫᴜᴇsᴛs", true);
        addDefault("tpa-here-requests", 39, "CLOCK", "&#08FB7Bᴛᴘᴀ ʜᴇʀᴇ ʀᴇǫᴜᴇsᴛs", true);
        addDefault("team-invites", 40, "SHIELD", "&#08FB7Bᴛᴇᴀᴍ ɪɴᴠɪᴛᴇs", true);
        addDefault("payments", 41, "EMERALD", "&#08FB7Bᴘᴀʏᴍᴇɴᴛs", true);
        addDefault("team-chat", 42, "BOOK", "&#08FB7Bᴛᴇᴀᴍ ᴄʜᴀᴛ", true);
        addDefault("worth-display", 43, "EXPERIENCE_BOTTLE", "&#08FB7Bᴡᴏʀᴛʜ ᴅɪsᴘʟᴀʏ", true);
    }

    private void addDefault(String id, int slot, String material, String name, boolean defaultEnabled) {
        options.put(id, new SettingOption(id, slot, material, name, List.of("&fCurrently: %status%"), defaultEnabled));
    }
}
